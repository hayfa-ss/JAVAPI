package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import models.Personne;
import services.PersonneService;

import java.sql.SQLException;

    public class Ajouterpersonnecontroller {


        PersonneService ps =new PersonneService();


        @FXML
        private TextField Nomp;

        @FXML
        private TextField prénomp;

        @FXML
        private TextField Agep;

       @FXML
        void ajouterpersonne(ActionEvent event) {
       try {
           ps.ajouter(new Personne(Integer.parseInt(Agep.getText()),Nomp.getText(),prénomp.getText()));

       } catch (SQLException e){
           Alert alert = new Alert(Alert.AlertType.ERROR);
           alert.setTitle("Error");
           alert.setContentText(e.getMessage());
           alert.showAndWait();
       }




        }}



